import './Banner-1.css';

function Navbar() {
  return (
    <div className="Banner__whole">
      <div className="Banner-1">
      <div className="rule__banner">
        
        </div>
    </div>
      <p className="hope">
          HOPE FOR HUMANITY
      </p>
      
    </div>
    
    
  );
}

export default Navbar;
